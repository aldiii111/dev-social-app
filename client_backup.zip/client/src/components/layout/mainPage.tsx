import { SidebarProvider, SidebarInset } from "@/components/ui/sidebar";
import { Route } from "react-router-dom";
import FeedPage from "@/pages/FeedPage";
import ProfilePage from "@/pages/ProfilePage";

export default function MainPage() {
  return (
    <SidebarProvider>
      
      <SidebarInset>
        <Route index element={<FeedPage />} />
        <Route path="page/feed" element={<FeedPage />} />
        {/* <Route path="page/addpost" element={<AddPostPage />} /> */}
        <Route path="page/profile" element={<ProfilePage />} />
      </SidebarInset>
    </SidebarProvider>
  );
}