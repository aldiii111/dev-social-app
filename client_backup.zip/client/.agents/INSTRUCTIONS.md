# Agentic AI Task Instructions

## 1. Kepemilikan Proyek
*   **Frontend (Client):** Dikerjakan bersama AI. Stack: React, Vite, TypeScript, Tailwind CSS v4, Shadcn UI, TanStack Query, Axios, Zod.
*   **Backend (Server):** Dikerjakan sendiri oleh user (bukan tim lain). Stack bebas pilihan user. AI tidak boleh auto-generate backend code kecuali diminta secara eksplisit.

## 2. Aturan Ketat Cara Kerja AI
*   **Dilarang auto-setup / auto-generate:** AI tidak boleh langsung menjalankan perintah instalasi, membuat file, atau scaffold kode tanpa permintaan eksplisit dari user.
*   **Hanya beri instruksi & code snippet:** Ketika user membutuhkan bantuan, AI cukup memberikan:
    1. Penjelasan singkat tentang apa yang perlu dilakukan.
    2. Langkah-langkah yang harus diikuti user.
    3. Code snippet / contoh kode yang bisa dicopy-paste.
*   **User yang mengeksekusi:** Semua perintah terminal, instalasi package, dan pembuatan file dijalankan sendiri oleh user.

## 3. Fokus Bantuan AI
*   Membantu membangun komponen UI presentasional (Shadcn UI + Tailwind CSS).
*   Mengarahkan state management lokal (buka/tutup modal, form state, dll).
*   Membimbing validasi form menggunakan Zod + React Hook Form.
*   Memetakan tipe data TypeScript sesuai skema database.
*   Memberikan flow & panduan integrasi API (endpoint, response shape) tanpa langsung generate implementasinya.
*   Membantu debug dan troubleshoot ketika user mengalami error — cukup jelaskan penyebab dan solusinya.

## 4. Aturan Backend
*   Backend dikerjakan oleh user sendiri (bukan teman/tim lain).
*   AI boleh membantu menjelaskan konsep backend (REST API design, auth flow, SQL query) jika ditanya.
*   AI **tidak** langsung men-generate file backend, konfigurasi server, atau migration script kecuali user secara eksplisit meminta code snippetnya.
