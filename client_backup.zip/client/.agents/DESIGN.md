🎨 Design System & UI/UX Guidelines
Project: Developer Social Media Web
Stack: React, Tailwind CSS, Shadcn/ui
Design Philosophy: Clean, Minimalist, Developer-Friendly, High Readability, Low Eye-Strain.

1. 🎨 Color Palette (Tailwind & CSS Variables)
Warna dirancang agar tidak mencolok (low saturation untuk background), dengan kontras yang cukup untuk keterbacaan (accessibility WCAG AA compliant). Kita menggunakan palet Zinc dari Tailwind sebagai basis karena netral dan elegan.

🌙 Dark Mode (Comfortable Dark)
Terinspirasi dari IDE modern (VS Code, Zed) dan dark mode premium. Tidak menggunakan #000000 murni untuk menghindari eye strain, melainkan zinc-950 dan zinc-900.
Token
Tailwind Class
Hex Value
Usage
background
bg-zinc-950
#09090b
Main page background
surface
bg-zinc-900
#18181b
Cards, Sidebars, Modals
surface-hover
hover:bg-zinc-800
#27272a
Interactive card/button hover
border
border-zinc-800
#27272a
Subtle dividers, card borders
primary
bg-zinc-100
#f4f4f5
Primary buttons, active states
primary-fg
text-zinc-900
#18181b
Text on primary buttons
text-primary
text-zinc-100
#f4f4f5
Main headings, body text
text-secondary
text-zinc-400
#a1a1aa
Metadata, timestamps, placeholders
accent
text-blue-400
#60a5fa
Links, mentions, active icons

☀️ Light Mode (WhatsApp / Claude Inspired)
Menggunakan putih bersih untuk kartu, dan semi-putih (off-white) untuk background utama agar tidak terlalu silau, mirip dengan kenyamanan visual WhatsApp Web dan antarmuka Claude.
Token
Tailwind Class
Hex Value
Usage
background
bg-[#F0F2F5]
#F0F2F5
Main page background (WhatsApp-like)
surface
bg-white
#FFFFFF
Cards, Sidebars, Modals (Claude-like clean)
surface-hover
hover:bg-zinc-50
#fafafa
Interactive card/button hover
border
border-zinc-200
#e4e4e7
Subtle dividers, card borders
primary
bg-zinc-900
#18181b
Primary buttons, active states
primary-fg
text-white
#ffffff
Text on primary buttons
text-primary
text-zinc-900
#18181b
Main headings, body text
text-secondary
text-zinc-500
#71717a
Metadata, timestamps, placeholders
accent
text-blue-600
#2563eb
Links, mentions, active icons

2. ⚙️ Tailwind & Shadcn Configuration
tailwind.config.ts
Pastikan dark mode diatur ke 'class' agar bisa ditoggle secara manual.

import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./pages/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./app/**/*.{ts,tsx}",
    "./src/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
};
export default config;

app/index.css (CSS Variables for Shadcn)
Ini adalah kunci agar tema Light (WhatsApp/Claude) dan Dark (Comfortable) bekerja sempurna dengan komponen Shadcn.

@tailwind base;
@tailwind components;
@tailwind utilities;

@layer base {
  :root {
    /* Light Mode (WhatsApp Semi-White + Claude Clean) */
    --background: 0 0% 95%; /* #F0F2F5 */
    --foreground: 240 10% 10%; /* #18181b (zinc-900) */
    
    --card: 0 0% 100%; /* #FFFFFF */
    --card-foreground: 240 10% 10%;
    
    --popover: 0 0% 100%;
    --popover-foreground: 240 10% 10%;
    
    --primary: 240 10% 10%; /* #18181b */
    --primary-foreground: 0 0% 100%;
    
    --secondary: 240 5% 96%; /* #f4f4f5 (zinc-100) */
    --secondary-foreground: 240 10% 10%;
    
    --muted: 240 5% 96%;
    --muted-foreground: 240 4% 46%; /* #71717a (zinc-500) */
    
    --accent: 240 5% 96%;
    --accent-foreground: 240 10% 10%;
    
    --destructive: 0 84.2% 60.2%;
    --destructive-foreground: 0 0% 100%;
    
    --border: 240 6% 90%; /* #e4e4e7 (zinc-200) */
    --input: 240 6% 90%;
    --ring: 240 10% 10%;
    
    --radius: 0.75rem; /* 12px - Modern rounded corners */
  }

  .dark {
    /* Dark Mode (Comfortable Black) */
    --background: 240 10% 4%; /* #09090b (zinc-950) */
    --foreground: 240 5% 96%; /* #f4f4f5 (zinc-100) */
    
    --card: 240 6% 10%; /* #18181b (zinc-900) */
    --card-foreground: 240 5% 96%;
    
    --popover: 240 6% 10%;
    --popover-foreground: 240 5% 96%;
    
    --primary: 240 5% 96%; /* #f4f4f5 (zinc-100) */
    --primary-foreground: 240 10% 10%;
    
    --secondary: 240 4% 16%; /* #27272a (zinc-800) */
    --secondary-foreground: 240 5% 96%;
    
    --muted: 240 4% 16%;
    --muted-foreground: 240 5% 65%; /* #a1a1aa (zinc-400) */
    
    --accent: 240 4% 16%;
    --accent-foreground: 240 5% 96%;
    
    --destructive: 0 62.8% 30.6%;
    --destructive-foreground: 0 0% 100%;
    
    --border: 240 4% 16%; /* #27272a (zinc-800) */
    --input: 240 4% 16%;
    --ring: 240 5% 96%;
  }
}

@layer base {
  * {
    @apply border-border;
  }
  body {
    @apply bg-background text-foreground antialiased;
    /* Smooth font rendering ala Claude/Medium */
    font-feature-settings: "rlig" 1, "calt" 1;
  }
}

3. 🔤 Typography
Menggunakan font yang sangat mudah dibaca untuk developer (monospace untuk kode, sans-serif clean untuk UI).
Primary Font: Inter atau Geist Sans (Default UI, headings, body).
Code/Mono Font: JetBrains Mono atau Fira Code (untuk snippet kode di feed).
Scale:
text-xs (12px): Timestamps, badges.
text-sm (14px): Body text, captions, button text.
text-base (16px): Default paragraph, input text.
text-lg (18px): Card titles, modal headers.
text-xl (20px): Page headings.
text-2xl (24px): Main profile names, major section headers.

4. 🧩 Core Components (Shadcn UI Adaptation)
A. Card (Feed Post / Widget)
Menggunakan border yang sangat subtle dan shadow yang hampir tidak terlihat di light mode, serta border zinc-800 di dark mode.

B. Button
Primary: Solid, high contrast. Di light mode: hitam di atas putih. Di dark mode: putih di atas hitam.
Ghost/Secondary: Untuk tombol like, reply, share. Menggunakan text-muted-foreground yang berubah menjadi text-accent-foreground dan bg-accent saat di-hover.

C. Avatar
Selalu berbentuk lingkaran sempurna (rounded-full) dengan border tipis (border-2 border-background) agar terpisah dari background kartu.

5. 📐 Layout & Spacing (Social Media Standard)
Max Width: Feed utama dibatasi max-w-2xl (672px) atau max-w-3xl (768px) di tengah layar agar baris teks tidak terlalu panjang (optimal readability: 60-75 karakter per baris).
Sidebar: w-64 (256px) fixed di kiri untuk navigasi utama (Desktop).
Right Panel: w-80 (320px) fixed di kanan untuk "Trending", "Suggested Developers", atau widget (Desktop).
Gap/Spacing: Gunakan space-y-4 atau gap-4 antar kartu di feed. Padding internal kartu standar: p-4 atau p-6.
Mobile: Sidebar menjadi Bottom Navigation Bar (h-16, fixed bottom, border-t).

6. ✨ Micro-Interactions & UX Polish (UIUXProMax Level)
Smooth Theme Transition: Tambahkan transition-colors duration-200 pada body dan elemen utama agar perpindahan Light/Dark mode tidak berkedip kasar.
Skeleton Loading: Gunakan komponen <Skeleton /> dari shadcn dengan warna bg-muted animate-pulse saat mengambil data feed, memberikan kesan aplikasi yang sangat responsif.
Hover States: Semua elemen yang bisa diklik harus memiliki transition-all duration-200 dan perubahan warna background yang subtle (misal: hover:bg-accent).
Focus Rings: Gunakan focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 untuk aksesibilitas keyboard yang baik, terutama pada input dan tombol.
Code Snippet Rendering: Jika ada blok kode di feed, gunakan background bg-zinc-950 (terlepas dari tema) dengan teks berwarna (syntax highlighting) agar terlihat seperti editor kode asli.

7. 🚀 Implementation Checklist
configure darkMode: 'class'.
Copy-paste CSS Variables di atas ke index.css.
Install Shadcn UI components:avatar
Buat komponen ThemeToggle untuk switch Light/Dark.
Terapkan layout 3-kolom (Sidebar, Feed, Widgets) dengan max-w-7xl mx-auto.

💡 Pro Tip: Untuk mendapatkan nuansa "Claude" yang paling otentik di Light Mode, pastikan tidak ada shadow yang berat (shadow-lg). Gunakan border yang sangat tipis (border-zinc-200) dan banyak whitespace (ruang kosong) antar elemen. Untuk Dark Mode, hindari warna abu-abu yang terlalu terang; pertahankan kedalaman dengan zinc-950 sebagai dasar dan zinc-900 hanya untuk elemen yang perlu "mengambang" (seperti kartu).